package com.example.platehunter

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Gemini Live transcription client (model gemini-3.5-transcribe-live) over raw WebSocket.
 * - Streams 16 kHz mono PCM16 in ~100 ms chunks.
 * - Receives interim (interimInputTranscription) and final (inputTranscription) text.
 * - Google limits a live transcription session to ~10 minutes, so a new session is opened
 *   in the background at ~9 minutes and swapped in without stopping the microphone.
 * - Reconnects automatically after a network failure while the user has not pressed stop.
 * API keys should be proxied by a backend for public releases.
 */
class GeminiLiveSpeech(private val onText: (String, Boolean) -> Unit, private val onStatus: (String) -> Unit) {
    companion object {
        const val MODEL = "models/gemini-3.5-transcribe-live"
        // Hint only. The Live transcription model lists Arabic (Egypt) as its Arabic code.
        val LANGUAGE_HINT = listOf("ar-EG")
        // Biases recognition toward spelled-out Arabic letter names used in plates.
        val VOCAB = listOf("ألف", "باء", "تاء", "جيم", "حاء", "خاء", "دال", "ذال", "راء", "زاي", "سين",
            "شين", "صاد", "ضاد", "طاء", "ظاء", "عين", "غين", "فاء", "قاف", "كاف", "لام", "ميم", "نون",
            "هاء", "واو", "ياء")
        private const val SESSION_MS = 9L * 60 * 1000
        private const val CHUNK_BYTES = 3200 // 100 ms @ 16 kHz mono 16-bit
    }

    private val client = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).pingInterval(20, TimeUnit.SECONDS).build()
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var active: WebSocket? = null   // socket that currently receives audio
    private var apiKey = ""
    private var recorder: AudioRecord? = null
    private var audioThread: Thread? = null
    private var failures = 0
    private val rotate = Runnable { if (running) openSocket(rotation = true) }

    fun start(key: String) {
        if (key.isBlank()) { onStatus("أدخل مفتاح Gemini من الإعدادات"); return }
        if (running) return
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { onStatus("تسجيل الصوت غير مدعوم على هذا الجهاز"); return }
        apiKey = key; failures = 0
        try {
            val r = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, CHUNK_BYTES * 2))
            if (r.state != AudioRecord.STATE_INITIALIZED) { onStatus("تعذر تهيئة الميكروفون"); r.release(); return }
            recorder = r; running = true; r.startRecording()
        } catch (e: Exception) { onStatus("خطأ في تشغيل الصوت: ${e.message}"); stop(); return }
        audioThread = Thread {
            val buf = ByteArray(CHUNK_BYTES)
            val r = recorder
            while (running && r != null) {
                var got = 0
                while (running && got < CHUNK_BYTES) {
                    val n = try { r.read(buf, got, CHUNK_BYTES - got) } catch (_: Exception) { -1 }
                    if (n <= 0) { if (n < 0) { got = -1; break } else continue }
                    got += n
                }
                if (got <= 0) break
                val ws = active ?: continue // dropped while (re)connecting
                val msg = JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject()
                    .put("data", Base64.encodeToString(buf, 0, got, Base64.NO_WRAP))
                    .put("mimeType", "audio/pcm;rate=16000")))
                ws.send(msg.toString())
            }
        }.apply { name = "PlateHunterGeminiAudio"; start() }
        openSocket(rotation = false)
    }

    private fun openSocket(rotation: Boolean) {
        if (!running) return
        if (!rotation) onStatus("جاري الاتصال بـ Gemini Live…")
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=" +
            java.net.URLEncoder.encode(apiKey, "UTF-8")
        val request = Request.Builder().url(url).build()
        client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val setup = JSONObject().put("setup", JSONObject()
                    .put("model", MODEL)
                    .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("TEXT")))
                    .put("inputAudioTranscription", JSONObject()
                        .put("languageCodes", JSONArray(LANGUAGE_HINT))
                        .put("customVocabulary", JSONArray(VOCAB))))
                webSocket.send(setup.toString())
            }
            override fun onMessage(webSocket: WebSocket, text: String) = handle(webSocket, text, rotation)
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) = handle(webSocket, bytes.utf8(), rotation)
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (webSocket !== active && !(rotation && active == null)) return // old socket dying, ignore
                if (active === webSocket) active = null
                if (!running) return
                failures++
                val code = response?.code
                if (code == 400 || code == 401 || code == 403 || failures > 30) {
                    onStatus("تعذر اتصال Gemini Live: ${t.message ?: code ?: "تحقق من المفتاح والإنترنت"}")
                    stop(); return
                }
                onStatus("انقطع Gemini Live — إعادة الاتصال…")
                main.postDelayed({ if (running && active == null) openSocket(rotation = false) }, minOf(1000L * failures, 5000L))
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (active === webSocket) {
                    active = null
                    if (running) main.postDelayed({ if (running && active == null) openSocket(rotation = false) }, 500)
                }
            }
        })
    }

    private fun handle(ws: WebSocket, raw: String, rotation: Boolean) {
        val root = try { JSONObject(raw) } catch (_: Exception) { return }
        if (root.has("setupComplete")) {
            val old = active
            active = ws; failures = 0
            main.removeCallbacks(rotate); main.postDelayed(rotate, SESSION_MS)
            if (old != null && old !== ws) {
                try { old.send("""{"realtimeInput":{"audioStreamEnd":true}}""") } catch (_: Exception) {}
                main.postDelayed({ try { old.close(1000, "rotated") } catch (_: Exception) {} }, 1500)
            }
            if (!rotation || old == null) onStatus("متصل بـ Gemini Live — الاستماع مباشر")
            return
        }
        if (ws !== active) { /* still deliver text from a session being retired */ }
        val sc = root.optJSONObject("serverContent") ?: return
        sc.optJSONObject("interimInputTranscription")?.optString("text")?.takeIf { it.isNotBlank() }?.let { onText(it, false) }
        sc.optJSONObject("inputTranscription")?.optString("text")?.takeIf { it.isNotBlank() }?.let { onText(it, true) }
    }

    fun stop() {
        running = false
        main.removeCallbacks(rotate)
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        val ws = active; active = null
        try { ws?.send("""{"realtimeInput":{"audioStreamEnd":true}}""") } catch (_: Exception) {}
        try { ws?.close(1000, "user stopped") } catch (_: Exception) {}
        audioThread = null
    }
}
