package com.example.platehunter

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val BG = 0xFF0E141B.toInt()
    private val CARD = 0xFF17202B.toInt()
    private val STROKE = 0xFF243140.toInt()
    private val FIELD = 0xFF0F161D.toInt()
    private val TEAL = 0xFF4CC3B0.toInt()
    private val RED = 0xFFFF6B6B.toInt()
    private val TEXT = 0xFFE8EEF4.toInt()
    private val MUTED = 0xFF8A97A6.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var status: TextView
    private lateinit var spoken: TextView
    private lateinit var recordsBox: LinearLayout
    private lateinit var listenButton: Button
    private lateinit var nameEdit: EditText
    private lateinit var platesCount: TextView
    private lateinit var wantedCount: TextView
    private lateinit var wantedHeader: TextView
    private lateinit var lastPlateView: TextView
    private val letterBoxes = mutableListOf<TextView>()
    private val digitBoxes = mutableListOf<TextView>()

    private var sr: SpeechRecognizer? = null
    private var listening = false
    private val records = mutableListOf<JSONObject>()
    private val wanted = mutableSetOf<String>()
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private var cloudSpeech: CloudSpeech? = null
    private var liveSpeech: GeminiLiveSpeech? = null
    private var lastLoc: Location? = null
    private val prefs by lazy { getSharedPreferences("platehunter_settings", MODE_PRIVATE) }
    private fun mode(): Int = prefs.getInt("mode", 0).coerceIn(0, 3)

    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) { lastLoc = location }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        override fun onStatusChanged(provider: String?, st: Int, extras: Bundle?) {}
    }

    // ---------- UI helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != null) setStroke(dp(1), stroke)
    }
    private fun tv(text: String, size: Float = 15f, color: Int = TEXT, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = bg(CARD, 20, STROKE)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, 0, 0, dp(12)) }
    }
    private fun btn(text: String, fill: Int, color: Int, size: Float = 16f) = Button(this).apply {
        this.text = text; setTextColor(color); background = bg(fill, 14); isAllCaps = false; textSize = size
        setTypeface(typeface, Typeface.BOLD)
    }
    private fun edit(hint: String) = EditText(this).apply {
        this.hint = hint; setHintTextColor(MUTED); setTextColor(TEXT); background = bg(FIELD, 14, STROKE)
        setPadding(dp(14), dp(12), dp(14), dp(12)); textSize = 16f; gravity = Gravity.START or Gravity.CENTER_VERTICAL
        setSingleLine(true)
    }
    private fun lp(w: Int = MATCH, h: Int = WRAP, top: Int = 0) = LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }
    private val openState = HashMap<TextView, Boolean>()
    private fun setTitle(h: TextView, title: String) {
        h.tag = title
        h.text = (if (openState[h] == true) "▼ " else "◄ ") + title
    }
    private fun collapsible(title: String, body: View): Pair<LinearLayout, TextView> {
        val c = card(); val h = tv("", 18f, TEXT, true)
        body.visibility = View.GONE; setTitle(h, title)
        h.setOnClickListener {
            val open = body.visibility != View.VISIBLE
            body.visibility = if (open) View.VISIBLE else View.GONE
            openState[h] = open; setTitle(h, h.tag as String)
        }
        c.addView(h); c.addView(body, lp(top = 10))
        return Pair(c, h)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG; window.navigationBarColor = BG
        ui()
        load()
        val missing = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION)
            .filter { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 4)
        render()
    }

    override fun onResume() { super.onResume(); startLocation() }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        startLocation()
    }

    // ---------- Screen ----------
    private fun ui() {
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(40), dp(14), dp(24)) }

        // Recorder name + date
        val head = card()
        val headRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        nameEdit = edit("اسم المسجِّل").apply {
            setText(prefs.getString("recorder", "")); inputType = InputType.TYPE_CLASS_TEXT
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { prefs.edit().putString("recorder", s.toString()).apply() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        headRow.addView(nameEdit, LinearLayout.LayoutParams(0, WRAP, 1f))
        headRow.addView(tv(SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date()), 22f, TEXT, true).apply { setPadding(dp(16), 0, dp(4), 0) })
        head.addView(headRow); content.addView(head)

        // Counters + plate boxes + listen button
        val main = card()
        val counters = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun counter(label: String, color: Int): TextView {
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            val num = tv("0", 44f, color, true).apply { gravity = Gravity.CENTER }
            col.addView(num); col.addView(tv(label, 20f, MUTED).apply { gravity = Gravity.CENTER })
            counters.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f)); return num
        }
        platesCount = counter("لوحات", TEXT)
        wantedCount = counter("مطلوبة", RED)
        main.addView(counters)

        val boxesRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun box(list: MutableList<TextView>) {
            val b = TextView(this).apply {
                gravity = Gravity.CENTER; textSize = 24f; setTextColor(TEXT); background = bg(FIELD, 14, STROKE)
            }
            list.add(b); boxesRow.addView(b, LinearLayout.LayoutParams(0, dp(56), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        repeat(3) { box(letterBoxes) }
        boxesRow.addView(View(this), LinearLayout.LayoutParams(0, dp(1), 0.5f))
        repeat(4) { box(digitBoxes) }
        main.addView(boxesRow, lp(top = 16))
        showPlate(null)

        status = tv("متوقف", 16f, MUTED).apply { gravity = Gravity.CENTER }
        spoken = tv("", 14f, MUTED).apply { gravity = Gravity.CENTER }
        main.addView(status, lp(top = 12)); main.addView(spoken, lp(top = 4))
        listenButton = btn("ابدأ الاستماع 🎤", TEAL, 0xFF06201C.toInt(), 22f).apply {
            setOnClickListener { if (listening) stopListening() else startListening() }
        }
        main.addView(listenButton, lp(h = dp(64), top = 16))
        content.addView(main)

        // Last plate
        val last = card()
        last.addView(tv("آخر لوحة", 15f, MUTED))
        lastPlateView = tv("—", 34f, TEAL, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)) }
        last.addView(lastPlateView); content.addView(last)

        // Manual entry
        val manual = card()
        val manualRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = edit("إدخال يدوي: س ب ح 7831")
        manualRow.addView(input, LinearLayout.LayoutParams(0, WRAP, 1f))
        manualRow.addView(btn("إضافة", 0xFF1D4A42.toInt(), TEAL).apply {
            setOnClickListener {
                val p = PlateParser.normalize(input.text.toString())
                if (p.isBlank()) toast("أدخل 3 حروف و3 أو 4 أرقام") else { savePlate(p, "manual"); input.setText("") }
            }
        }, LinearLayout.LayoutParams(WRAP, dp(52)).apply { marginStart = dp(10) })
        manual.addView(manualRow); content.addView(manual)

        // Wanted list
        val wantedBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wantedBody.addView(tv("استورد ملف Excel (XLSX) أو CSV فيه عمود اللوحات.", 13f, MUTED))
        wantedBody.addView(btn("استيراد المطلوبين من Excel أو CSV", 0xFF1D4A42.toInt(), TEAL, 15f).apply {
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/csv", "text/plain", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                }
                startActivityForResult(i, 10)
            }
        }, lp(top = 8))
        wantedBody.addView(btn("مسح قائمة المطلوبين", 0xFF3A1D22.toInt(), RED, 15f).apply {
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setMessage("مسح قائمة المطلوبين؟")
                    .setPositiveButton("مسح") { _, _ ->
                        wanted.clear(); saveWanted()
                        records.forEach { it.put("matched", false) }; persist(); render()
                    }.setNegativeButton("إلغاء", null).show()
            }
        }, lp(top = 8))
        val (wantedCard, wh) = collapsible("قائمة المطلوبين (0)", wantedBody)
        wantedHeader = wh; content.addView(wantedCard)

        // Speech engine
        val engineBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val modeNames = listOf("محلي من أندرويد (قد يحتاج إنترنت)", "Deepgram مباشر", "Deepgram + Gemini عند الحاجة", "Gemini Live مباشر")
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        modeNames.forEachIndexed { i, n ->
            group.addView(RadioButton(this).apply { id = 100 + i; text = n; setTextColor(TEXT); textSize = 16f; isChecked = i == mode() })
        }
        group.setOnCheckedChangeListener { _, id -> prefs.edit().putInt("mode", id - 100).apply() }
        engineBody.addView(group)
        engineBody.addView(btn("⚙️ مفاتيح Deepgram وGemini", 0xFF1D4A42.toInt(), TEAL, 15f).apply { setOnClickListener { showApiSettings() } }, lp(top = 8))
        content.addView(collapsible("محرك التعرف على الكلام", engineBody).first)

        // Teach letters
        content.addView(collapsible("تعليم المايك الحروف", mapEditor("letter_map",
            "لو المايك يسمع الحرف بكلمة مختلفة، علّمه: اكتب الكلمة كما يسمعها والحرف المقصود.",
            "الكلمة المسموعة (مثل: سن)", "الحرف (مثل: س)", true) { PlateParser.extraLetters = it }).first)

        // Word corrections
        content.addView(collapsible("تصحيح الكلمات", mapEditor("corr_map",
            "استبدل كلمة يخطئ فيها التفريغ بالكلمة الصحيحة قبل استخراج اللوحة.",
            "الكلمة الخاطئة", "الكلمة الصحيحة", false) { PlateParser.corrections = it }).first)

        // Log
        val log = card()
        val logHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        logHead.addView(tv("السجل", 20f, TEXT, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        logHead.addView(btn("Excel 📥", 0xFF1D4A42.toInt(), TEAL, 15f).apply { setOnClickListener { export() } }, LinearLayout.LayoutParams(WRAP, dp(48)))
        logHead.addView(btn("🗑️ مسح السجل", 0xFF3A1D22.toInt(), RED, 15f).apply {
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setMessage("مسح كل السجل؟ لا يمكن التراجع.")
                    .setPositiveButton("مسح") { _, _ -> records.clear(); persist(); render(); showPlate(null); lastPlateView.text = "—" }
                    .setNegativeButton("إلغاء", null).show()
            }
        }, LinearLayout.LayoutParams(WRAP, dp(48)).apply { marginStart = dp(8) })
        log.addView(logHead)
        log.addView(row("اللوحة", "الحالة", "الوقت", "الموقع", MUTED, null, null), lp(top = 12))
        recordsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        log.addView(recordsBox)
        content.addView(log)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG); layoutDirection = View.LAYOUT_DIRECTION_RTL; isFillViewport = true
            addView(content)
        })
    }

    private fun row(a: String, b: String, c: String, d: String, color: Int, statusColor: Int?, onLoc: (() -> Unit)?): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        fun cell(t: String, w: Float, col: Int, bold: Boolean = false) =
            tv(t, 14f, col, bold).apply { gravity = Gravity.START }.also { r.addView(it, LinearLayout.LayoutParams(0, WRAP, w)) }
        cell(a, 1.4f, if (color == MUTED) MUTED else TEXT, color != MUTED)
        cell(b, 1f, statusColor ?: color)
        cell(c, 1.2f, color)
        val loc = cell(d, 1f, if (onLoc != null) TEAL else color, onLoc != null)
        if (onLoc != null) { loc.setPadding(0, dp(8), 0, dp(8)); loc.setOnClickListener { onLoc() } }
        return r
    }

    private fun showPlate(p: String?) {
        val letters = p?.take(3).orEmpty(); val digits = p?.drop(3).orEmpty()
        letterBoxes.forEachIndexed { i, b -> b.text = letters.getOrNull(i)?.toString() ?: "" }
        digitBoxes.forEachIndexed { i, b -> b.text = digits.getOrNull(i)?.toString() ?: "•" }
    }

    private fun mapEditor(prefKey: String, desc: String, hintFrom: String, hintTo: String, singleLetter: Boolean, onChange: (Map<String, String>) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(tv(desc, 13f, MUTED))
        val from = edit(hintFrom); val to = edit(hintTo)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun read(): MutableMap<String, String> {
            val m = linkedMapOf<String, String>()
            try { val o = JSONObject(prefs.getString(prefKey, "{}") ?: "{}"); o.keys().forEach { m[it] = o.getString(it) } } catch (_: Exception) {}
            return m
        }
        fun write(m: Map<String, String>) { prefs.edit().putString(prefKey, JSONObject(m as Map<*, *>).toString()).apply() }
        fun refresh() {
            val m = read(); onChange(m); list.removeAllViews()
            m.forEach { (k, v) ->
                list.addView(tv("$k  ←  $v      ✕", 15f, TEXT).apply {
                    setPadding(0, dp(8), 0, dp(8))
                    setOnClickListener { val mm = read(); mm.remove(k); write(mm); refresh() }
                })
            }
        }
        box.addView(from, lp(top = 8)); box.addView(to, lp(top = 8))
        box.addView(btn("إضافة", 0xFF1D4A42.toInt(), TEAL, 15f).apply {
            setOnClickListener {
                val k = from.text.toString().trim(); val v = to.text.toString().trim()
                if (k.isBlank() || v.isBlank()) { toast("اكتب الحقلين"); return@setOnClickListener }
                if (singleLetter && !(v.length == 1 && v[0] in '\u0621'..'\u064A')) { toast("اكتب حرفًا عربيًا واحدًا"); return@setOnClickListener }
                val m = read(); m[k] = v; write(m); from.setText(""); to.setText(""); refresh()
            }
        }, lp(top = 8))
        box.addView(list, lp(top = 8))
        refresh()
        return box
    }

    // ---------- Listening ----------
    private fun setListeningUi(on: Boolean) {
        listening = on
        listenButton.text = if (on) "⏹ إيقاف الاستماع" else "ابدأ الاستماع 🎤"
        listenButton.background = bg(if (on) RED else TEAL, 14)
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
    private fun setStatus(s: String, color: Int = MUTED) { status.text = s; status.setTextColor(color) }

    private fun hasMic() = ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startListening() {
        if (!hasMic()) { ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 4); return }
        when (mode()) {
            3 -> {
                val gk = prefs.getString("gemini_key", "").orEmpty()
                if (gk.isBlank()) { showApiSettings(); toast("أدخل مفتاح Gemini أولًا"); return }
                setListeningUi(true); setStatus("جاري الاتصال بـ Gemini Live…")
                liveSpeech = GeminiLiveSpeech({ transcript, isFinal -> runOnUiThread {
                    spoken.text = transcript
                    if (isFinal) {
                        val plates = PlateParser.fromSpeech(transcript)
                        if (plates.isNotEmpty()) plates.forEach { savePlate(it, "gemini-live") }
                        else setStatus("لم أستخرج لوحة واضحة")
                    }
                } }, { message -> runOnUiThread {
                    setStatus(message)
                    if (message.startsWith("تعذر")) setListeningUi(false)
                } }).also { it.start(gk) }
            }
            1, 2 -> {
                val dg = prefs.getString("deepgram_key", "").orEmpty()
                if (dg.isBlank()) { showApiSettings(); toast("أدخل مفتاح Deepgram أولًا"); return }
                setListeningUi(true); setStatus("جاري الاتصال بـ Deepgram…")
                cloudSpeech = CloudSpeech({ transcript, isFinal -> runOnUiThread {
                    spoken.text = transcript
                    val plates = if (isFinal) PlateParser.fromSpeech(transcript) else emptyList()
                    if (plates.isNotEmpty()) plates.forEach { savePlate(it, if (mode() == 2) "deepgram+gemini" else "deepgram") }
                    else if (isFinal && mode() == 2) {
                        setStatus("النص غير واضح؛ Gemini يحاول استخراج اللوحة…")
                        Thread {
                            val p = GeminiPlateHelper.extractPlate(prefs.getString("gemini_key", "").orEmpty(), transcript)
                            runOnUiThread { if (!p.isNullOrBlank() && listening) savePlate(p, "deepgram+gemini") else if (listening) setStatus("لم يتم استخراج لوحة مؤكدة") }
                        }.start()
                    } else if (isFinal) setStatus("لم أستخرج لوحة واضحة")
                } }, { message -> runOnUiThread {
                    setStatus(message)
                    if (message.startsWith("تعذر")) setListeningUi(false)
                } }).also { it.start(dg) }
            }
            else -> startLocalRecognition()
        }
    }

    private fun startLocalRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { toast("خدمة التعرف على الكلام غير متاحة"); return }
        setListeningUi(true); setStatus("🎙️ جاري الاستماع")
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { sr?.destroy() } catch (_: Exception) {}
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { setStatus("الميكروفون جاهز") }
            override fun onBeginningOfSpeech() { setStatus("بسمعك...") }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { restart(intent) }
            override fun onResults(results: Bundle?) {
                results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(::process)
                restart(intent)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { spoken.text = it }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        try { sr?.startListening(intent) } catch (_: Exception) { setStatus("تعذر بدء الميكروفون") }
    }

    private fun restart(intent: Intent) {
        if (!listening) return
        window.decorView.postDelayed({
            if (listening) try { sr?.cancel(); sr?.startListening(intent) }
            catch (_: Exception) { setStatus("توقف الاستماع؛ اضغط ابدأ الاستماع مرة أخرى") }
        }, 400)
    }

    private fun process(s: String) {
        spoken.text = s
        val ps = PlateParser.fromSpeech(s)
        if (ps.isEmpty()) setStatus("لم أستخرج لوحة واضحة") else ps.forEach { savePlate(it, "voice") }
    }

    private fun stopListening() {
        setListeningUi(false)
        try { cloudSpeech?.stop() } catch (_: Exception) {}; cloudSpeech = null
        try { liveSpeech?.stop() } catch (_: Exception) {}; liveSpeech = null
        try { sr?.cancel(); sr?.destroy() } catch (_: Exception) {}
        sr = null; setStatus("متوقف")
    }

    // ---------- Location ----------
    private fun hasLoc() = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun startLocation() {
        if (!hasLoc()) return
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            lm.removeUpdates(locListener)
            listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).forEach { p ->
                try { if (lm.isProviderEnabled(p)) lm.requestLocationUpdates(p, 5000L, 0f, locListener) } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }

    private fun location(): Location? {
        if (!hasLoc()) return null
        return try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            listOfNotNull(
                lastLoc,
                try { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) } catch (_: Exception) { null },
                try { lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) } catch (_: Exception) { null }
            ).maxByOrNull { it.time }
        } catch (_: Exception) { null }
    }

    /** Opens the map app (GPS position) at the saved coordinates. */
    private fun openMap(lat: Double, lon: Double) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon")))
        } catch (_: Exception) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lon"))) }
            catch (_: Exception) { toast("لا يوجد تطبيق خرائط") }
        }
    }

    // ---------- Data ----------
    private fun savePlate(p: String, method: String) {
        val nowMs = System.currentTimeMillis()
        val last = records.lastOrNull()
        if (last != null && last.optString("plate") == p && nowMs - last.optLong("epoch") < 8000) return
        val loc = location()
        val isWanted = wanted.contains(p)
        val r = JSONObject().apply {
            put("plate", p); put("timestamp", fmt.format(Date())); put("epoch", nowMs); put("method", method)
            put("lat", loc?.latitude ?: JSONObject.NULL); put("lon", loc?.longitude ?: JSONObject.NULL)
            put("recorder", nameEdit.text.toString().trim())
            put("matched", isWanted)
        }
        records.add(r); persist(); render()
        showPlate(p); lastPlateView.text = p
        lastPlateView.setTextColor(if (isWanted) RED else TEAL)
        if (isWanted) {
            setStatus("⚠️ $p مطلوبة!", RED)
            try { (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE)) } catch (_: Exception) {}
        } else setStatus("تم تسجيل $p")
    }

    private fun load() {
        try {
            val f = File(filesDir, "records.json")
            if (f.exists()) { val a = JSONArray(f.readText()); for (i in 0 until a.length()) records.add(a.getJSONObject(i)) }
        } catch (_: Exception) {}
        try {
            val w = File(filesDir, "wanted.txt")
            if (w.exists()) w.readLines().filter { it.isNotBlank() }.forEach { wanted.add(it.trim()) }
        } catch (_: Exception) {}
        records.lastOrNull()?.let { showPlate(it.optString("plate")); lastPlateView.text = it.optString("plate") }
    }
    private fun persist() {
        try { val a = JSONArray(); records.forEach { a.put(it) }; File(filesDir, "records.json").writeText(a.toString()) }
        catch (_: Exception) { toast("تعذر حفظ السجلات") }
    }
    private fun saveWanted() {
        try { File(filesDir, "wanted.txt").writeText(wanted.joinToString("\n")) } catch (_: Exception) { toast("تعذر حفظ قائمة المطلوبين") }
    }

    private fun render() {
        if (!::recordsBox.isInitialized) return
        platesCount.text = records.size.toString()
        wantedCount.text = records.count { it.optBoolean("matched") }.toString()
        setTitle(wantedHeader, "قائمة المطلوبين (${wanted.size})")
        recordsBox.removeAllViews()
        records.takeLast(100).reversed().forEach { r ->
            val matched = r.optBoolean("matched")
            val lat = r.optDouble("lat", Double.NaN); val lon = r.optDouble("lon", Double.NaN)
            val located = lat.isFinite() && lon.isFinite()
            recordsBox.addView(row(
                r.optString("plate"), if (matched) "مطلوبة" else "عادية",
                r.optString("timestamp").substringAfter(' '), if (located) "📍 فتح" else "—",
                TEXT, if (matched) RED else MUTED, if (located) ({ openMap(lat, lon) }) else null
            ).apply { background = bg(if (matched) 0xFF2A1B20.toInt() else CARD, 10) })
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == RESULT_OK) {
            try {
                val uri = data?.data ?: return
                val imported = SpreadsheetReader.readPlateColumn(contentResolver, uri)
                    .mapNotNull { PlateParser.normalize(it).takeIf(String::isNotBlank) }
                wanted.clear(); wanted.addAll(imported); saveWanted()
                records.forEach { it.put("matched", wanted.contains(it.optString("plate"))) }
                persist(); render(); toast("تم استيراد ${wanted.size} لوحة ومطابقة السجلات")
            } catch (e: Exception) {
                toast(e.message ?: "تعذر قراءة الملف؛ جرّب XLSX أو CSV")
            }
        }
    }

    private fun export() {
        if (records.isEmpty()) { toast("السجل فارغ"); return }
        try {
            val csv = buildString {
                append("\uFEFFاللوحة,الحالة,الوقت,خط العرض,خط الطول,رابط الخريطة,المسجِّل,طريقة الالتقاط\n")
                records.forEach { r ->
                    val lat = r.optDouble("lat", Double.NaN); val lon = r.optDouble("lon", Double.NaN)
                    val ok = lat.isFinite() && lon.isFinite()
                    val cols = listOf(r.optString("plate"), if (r.optBoolean("matched")) "مطلوبة" else "عادية", r.optString("timestamp"),
                        if (ok) lat.toString() else "", if (ok) lon.toString() else "",
                        if (ok) "https://maps.google.com/?q=$lat,$lon" else "", r.optString("recorder"), r.optString("method"))
                    append(cols.joinToString(",") { "\"${it.replace("\"", "\"\"")}\"" }).append('\n')
                }
            }
            val f = File(cacheDir, "plate_records.csv"); f.writeText(csv, Charsets.UTF_8)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "تصدير السجلات"))
        } catch (_: Exception) { toast("تعذر التصدير") }
    }

    private fun showApiSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val deepgram = EditText(this).apply { hint = "Deepgram API Key"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setText(prefs.getString("deepgram_key", "")) }
        val gemini = EditText(this).apply { hint = "Gemini API Key (لوضع Gemini Live والاحتياطي)"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setText(prefs.getString("gemini_key", "")) }
        box.addView(TextView(this).apply { text = "للاستخدام الشخصي فقط: حفظ المفتاح داخل الهاتف ليس حماية كاملة. لا تنشر APK بمفاتيحك."; textSize = 13f })
        box.addView(deepgram); box.addView(gemini)
        AlertDialog.Builder(this).setTitle("إعداد مفاتيح API").setView(box)
            .setPositiveButton("حفظ") { _, _ -> prefs.edit().putString("deepgram_key", deepgram.text.toString().trim()).putString("gemini_key", gemini.text.toString().trim()).apply(); toast("تم حفظ الإعدادات على هذا الهاتف") }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() {
        listening = false
        try { cloudSpeech?.stop() } catch (_: Exception) {}
        try { liveSpeech?.stop() } catch (_: Exception) {}
        try { sr?.destroy() } catch (_: Exception) {}
        try { (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(locListener) } catch (_: Exception) {}
        super.onDestroy()
    }
}
