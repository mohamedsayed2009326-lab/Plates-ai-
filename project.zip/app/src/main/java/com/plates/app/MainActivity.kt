package com.plates.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.WindowManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.EditText
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var am: AudioManager
    private var sr: SpeechRecognizer? = null
    private var on = false
    private val h = Handler(Looper.getMainLooper())
    private var fileCb: ValueCallback<Array<Uri>>? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        web = WebView(this)
        setContentView(web)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = true
        s.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String?, cb: GeolocationPermissions.Callback?) {
                cb?.invoke(origin, true, false)
            }
            override fun onShowFileChooser(w: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    val i = Intent(Intent.ACTION_GET_CONTENT)
                    i.addCategory(Intent.CATEGORY_OPENABLE)
                    i.type = "*/*"
                    startActivityForResult(i, 7)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }
            override fun onJsPrompt(v: WebView?, url: String?, msg: String?, def: String?, r: JsPromptResult?): Boolean {
                val et = EditText(this@MainActivity)
                et.setText(def ?: "")
                AlertDialog.Builder(this@MainActivity).setTitle(msg).setView(et)
                    .setPositiveButton("حفظ") { _, _ -> r?.confirm(et.text.toString()) }
                    .setNegativeButton("إلغاء") { _, _ -> r?.cancel() }
                    .setOnCancelListener { r?.cancel() }
                    .show()
                return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION), 1)
    }

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        if (rq == 7) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d))
            fileCb = null
        } else super.onActivityResult(rq, rs, d)
    }

    private fun js(c: String) { web.post { web.evaluateJavascript(c, null) } }
    private fun send(t: String) = js("onNativeText(" + JSONObject.quote(t) + ")")

    private fun mute(m: Boolean) {
        val d = if (m) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
        for (s in intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION)) {
            try { am.adjustStreamVolume(s, d, 0) } catch (e: Exception) { }
        }
    }

    private fun destroySr() {
        h.removeCallbacksAndMessages(null)
        try { sr?.destroy() } catch (e: Exception) { }
        sr = null
    }

    private fun again(ms: Long) { h.postDelayed({ listen() }, ms) }

    private fun fail(msg: String) {
        on = false
        destroySr()
        mute(false)
        js("nativeErr(" + JSONObject.quote(msg) + ")")
    }

    private fun listen() {
        if (!on) return
        destroySr()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            fail("خدمة التعرف على الصوت غير متاحة — فعّل تطبيق Google"); return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                if (!on) return
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null) send(t)
                js("nativeEnd()")
                again(60)
            }
            override fun onPartialResults(b: Bundle?) {
                if (!on) return
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null) send(t)
            }
            override fun onError(e: Int) {
                if (!on) return
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    fail("اسمح للتطبيق بالميكروفون من إعدادات أندرويد"); return
                }
                js("nativeEnd()")
                again(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 500 else 80)
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        r.startListening(i)
    }

    inner class Bridge {
        @JavascriptInterface fun start() {
            runOnUiThread {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    fail("اسمح للتطبيق بالميكروفون من إعدادات أندرويد")
                } else {
                    on = true
                    mute(true)
                    listen()
                }
            }
        }
        @JavascriptInterface fun stop() {
            runOnUiThread { on = false; destroySr(); mute(false) }
        }
        @JavascriptInterface fun beep() {
            try {
                val t = ToneGenerator(AudioManager.STREAM_ALARM, 100)
                t.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 500)
                h.postDelayed({ t.release() }, 800)
            } catch (e: Exception) { }
        }
    }

    override fun onDestroy() {
        on = false
        destroySr()
        mute(false)
        super.onDestroy()
    }
}
