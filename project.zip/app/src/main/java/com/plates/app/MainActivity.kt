package com.plates.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.WindowManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.EditText
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var am: AudioManager
    private var sr: SpeechRecognizer? = null
    private var on = false
    private val h = Handler(Looper.getMainLooper())
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingFile: ByteArray? = null
    @Volatile private var preferOffline = false
    @Volatile private var segmented = false
    private val BIAS = listOf("ألف", "باء", "تاء", "ثاء", "جيم", "حاء", "خاء", "دال", "ذال", "راء", "زاي", "سين", "شين", "صاد", "ضاد", "طاء", "ظاء", "عين", "غين", "فاء", "قاف", "كاف", "لام", "ميم", "نون", "هاء", "واو", "ياء", "صفر", "واحد", "اتنين", "تلاتة", "اربعة", "خمسة", "ستة", "سبعة", "تمانية", "تسعة")
    private var tts: android.speech.tts.TextToSpeech? = null
    private var ttsOk = false
    @Volatile private var aiOn = false
    @Volatile private var aiGen = 0
    private val aiPool = java.util.concurrent.Executors.newFixedThreadPool(3)
    private val aiLock = Any()
    private var aiNext = 0
    private var aiSeq = 0
    private val aiDone = HashMap<Int, String?>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        web = WebView(this)
        setContentView(web)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = true
        s.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String?, cb: GeolocationPermissions.Callback?) {
                cb?.invoke(origin, true, false)
            }
            override fun onShowFileChooser(w: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    val i = Intent(Intent.ACTION_GET_CONTENT)
                    i.addCategory(Intent.CATEGORY_OPENABLE)
                    i.type = "*/*"
                    startActivityForResult(i, 7)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }
            override fun onJsPrompt(v: WebView?, url: String?, msg: String?, def: String?, r: JsPromptResult?): Boolean {
                val et = EditText(this@MainActivity)
                et.setText(def ?: "")
                AlertDialog.Builder(this@MainActivity).setTitle(msg).setView(et)
                    .setPositiveButton("حفظ") { _, _ -> r?.confirm(et.text.toString()) }
                    .setNegativeButton("إلغاء") { _, _ -> r?.cancel() }
                    .setOnCancelListener { r?.cancel() }
                    .show()
                return true
            }
        }
        tts = android.speech.tts.TextToSpeech(this) { st ->
            if (st == android.speech.tts.TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(java.util.Locale("ar"))
                ttsOk = r != null && r >= android.speech.tts.TextToSpeech.LANG_AVAILABLE
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION), 1)
    }

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        if (rq == 7) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d))
            fileCb = null
        } else if (rq == 8) {
            val u = d?.data
            val b = pendingFile
            pendingFile = null
            if (rs == RESULT_OK && u != null && b != null) {
                try {
                    contentResolver.openOutputStream(u)?.use { it.write(b) }
                    js("nativeMsg(" + JSONObject.quote("تم حفظ الملف ✓") + ")")
                } catch (e: Exception) {
                    js("nativeMsg(" + JSONObject.quote("تعذّر حفظ الملف") + ")")
                }
            }
        } else super.onActivityResult(rq, rs, d)
    }

    private fun js(c: String) { web.post { web.evaluateJavascript(c, null) } }
    private fun send(t: String) = js("onNativeText(" + JSONObject.quote(t) + ")")

    private fun mute(m: Boolean) {
        val d = if (m) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
        for (s in intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION)) {
            try { am.adjustStreamVolume(s, d, 0) } catch (e: Exception) { }
        }
    }

    private fun destroySr() {
        h.removeCallbacksAndMessages(null)
        try { sr?.destroy() } catch (e: Exception) { }
        sr = null
    }

    private fun again(ms: Long) { h.postDelayed({ listen() }, ms) }

    private fun fail(msg: String) {
        on = false
        aiOn = false
        aiGen++
        destroySr()
        mute(false)
        js("nativeErr(" + JSONObject.quote(msg) + ")")
    }

    private fun listen() {
        if (!on) return
        destroySr()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            fail("خدمة التعرف على الصوت غير متاحة — فعّل تطبيق Google"); return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                if (!on) return
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null) send(t)
                js("nativeEnd()")
                again(60)
            }
            override fun onPartialResults(b: Bundle?) {
                if (!on) return
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null) send(t)
            }
            override fun onError(e: Int) {
                if (!on) return
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    fail("اسمح للتطبيق بالميكروفون من إعدادات أندرويد"); return
                }
                js("nativeEnd()")
                again(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 500 else 80)
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onSegmentResults(b: Bundle) {
                if (!on) return
                val t = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null) send(t)
                js("nativeEnd()")
            }
            override fun onEndOfSegmentedSession() {
                if (!on) return
                js("nativeEnd()")
                again(60)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        if (preferOffline) i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        if (Build.VERSION.SDK_INT >= 33) {
            i.putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, ArrayList<String>(BIAS))
            if (segmented) i.putExtra(RecognizerIntent.EXTRA_SEGMENTED_SESSION, true)
        }
        r.startListening(i)
    }

    private val PROMPT = """أنت تسمع شخصاً مصرياً ينطق لوحات سيارات مصرية: حروف عربية (قد ينطقها كأسماء حروف مثل سين، باء، حاء، راء، عين، أو كحروف متتالية مثل سبح) ثم أرقام. اكتب اللوحة فقط بهذا الشكل بالضبط: الحروف العربية مفصولة بمسافات ثم الأرقام بالإنجليزية، مثل: س ب ح 7831. الحرف المكرر يُكتب مرتين. قد يقول المتحدث عدة لوحات متتالية بدون توقف؛ كل لوحة غالباً ثلاثة حروف ثم أربعة أرقام. اكتب كل لوحة تسمعها في سطر مستقل بالترتيب، ولا تدمج لوحتين في سطر ولا تحذف أي حرف أو رقم. إذا بدأ التسجيل أو انتهى في منتصف لوحة فاكتب ما سمعته منها فقط. لا تضف أي شرح. إذا لم تسمع لوحة اكتب NONE."""
    private val WPROMPT = "سين باء جيم دال راء صاد عين فاء قاف كاف لام ميم نون هاء واو ياء حاء خاء طاء 1234 5678"

    private fun wavOf(pcm: ByteArray): ByteArray {
        val rate = 16000
        val bb = java.nio.ByteBuffer.allocate(44 + pcm.size).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + pcm.size); bb.put("WAVE".toByteArray()); bb.put("fmt ".toByteArray())
        bb.putInt(16); bb.putShort(1); bb.putShort(1); bb.putInt(rate); bb.putInt(rate * 2); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(pcm.size); bb.put(pcm)
        return bb.array()
    }

    @Volatile private var goodModel: String? = null

    private fun postAi(model: String, key: String, body: String): Pair<Int, String> {
        val c = java.net.URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent").openConnection() as java.net.HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 10000
        c.readTimeout = 25000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.doOutput = true
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        return Pair(code, stream?.bufferedReader()?.readText() ?: "")
    }

    private fun postGroq(key: String, wav: ByteArray): Pair<Int, String> {
        val bd = "----plates" + System.currentTimeMillis()
        val c = java.net.URL("https://api.groq.com/openai/v1/audio/transcriptions").openConnection() as java.net.HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 10000
        c.readTimeout = 25000
        c.setRequestProperty("Authorization", "Bearer " + key)
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + bd)
        c.doOutput = true
        c.outputStream.use { o ->
            val fields = listOf("model" to "whisper-large-v3-turbo", "language" to "ar", "response_format" to "json", "temperature" to "0", "prompt" to WPROMPT)
            for (f in fields) {
                o.write(("--" + bd + "\r\nContent-Disposition: form-data; name=\"" + f.first + "\"\r\n\r\n" + f.second + "\r\n").toByteArray())
            }
            o.write(("--" + bd + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"a.wav\"\r\nContent-Type: audio/wav\r\n\r\n").toByteArray())
            o.write(wav)
            o.write(("\r\n--" + bd + "--\r\n").toByteArray())
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        return Pair(code, stream?.bufferedReader()?.readText() ?: "")
    }

    private fun postDeepgram(key: String, wav: ByteArray): Pair<Int, String> {
        val q = StringBuilder("https://api.deepgram.com/v1/listen?model=nova-3&language=ar-EG&punctuate=false")
        for (k in BIAS) q.append("&keyterm=").append(java.net.URLEncoder.encode(k, "UTF-8"))
        val c = java.net.URL(q.toString()).openConnection() as java.net.HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 10000
        c.readTimeout = 25000
        c.setRequestProperty("Authorization", "Token " + key)
        c.setRequestProperty("Content-Type", "audio/wav")
        c.doOutput = true
        c.outputStream.use { it.write(wav) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        return Pair(code, stream?.bufferedReader()?.readText() ?: "")
    }

    private fun aiErr(name: String, code: Int, body: String) {
        val hint = when (code) {
            400, 401, 403 -> " — تأكد من المفتاح"
            404 -> " — اسم النموذج غير صحيح"
            429 -> " — تجاوزت حد الاستخدام"
            500, 503 -> " — الخوادم مشغولة، جرّب بعد شوية"
            else -> ""
        }
        val msg = try { JSONObject(body).getJSONObject("error").getString("message").take(70) } catch (e: Exception) {
            try { JSONObject(body).getString("err_msg").take(70) } catch (e2: Exception) { "" }
        }
        js("nativeMsg(" + JSONObject.quote("خطأ " + name + " " + code + hint + " " + msg) + ")")
    }

    private fun emit(gen: Int, seq: Int, text: String?) {
        synchronized(aiLock) {
            if (gen != aiGen) return
            aiDone[seq] = text
            while (aiDone.containsKey(aiNext)) {
                val t = aiDone.remove(aiNext)
                aiNext++
                if (t != null && aiOn) js("onAIText(" + JSONObject.quote(t) + ")")
            }
        }
    }

    private fun sendAi(pcm: ByteArray, engine: String, key: String, model: String) {
        val gen = aiGen
        val seq = synchronized(aiLock) { aiSeq++ }
        js("nativeMsg(" + JSONObject.quote("⏳ جاري التحليل...") + ")")
        aiPool.execute {
            try {
                val wav = wavOf(pcm)
                if (engine == "dg") {
                    var r = postDeepgram(key, wav)
                    if (r.first == 429 || r.first == 503 || r.first == 500) {
                        Thread.sleep(1200)
                        r = postDeepgram(key, wav)
                    }
                    if (r.first != 200) {
                        aiErr("Deepgram", r.first, r.second)
                        emit(gen, seq, null)
                        return@execute
                    }
                    val out = JSONObject(r.second).getJSONObject("results").getJSONArray("channels").getJSONObject(0)
                        .getJSONArray("alternatives").getJSONObject(0).getString("transcript").trim()
                    emit(gen, seq, if (out.isEmpty()) null else out)
                } else if (engine == "groq") {
                    var r = postGroq(key, wav)
                    if (r.first == 429 || r.first == 503 || r.first == 500) {
                        Thread.sleep(1200)
                        r = postGroq(key, wav)
                    }
                    if (r.first != 200) {
                        aiErr("Groq", r.first, r.second)
                        emit(gen, seq, null)
                        return@execute
                    }
                    val out = JSONObject(r.second).getString("text").trim()
                    emit(gen, seq, if (out.isEmpty()) null else out)
                } else {
                    val b64 = android.util.Base64.encodeToString(wav, android.util.Base64.NO_WRAP)
                    val part1 = JSONObject().put("text", PROMPT)
                    val part2 = JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav").put("data", b64))
                    val body = JSONObject()
                        .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(part1).put(part2))))
                        .toString()
                    var res: Pair<Int, String>? = null
                    var used = model
                    for (attempt in 0..1) {
                        for (m in listOfNotNull(goodModel, model, "gemini-3.1-flash-lite", "gemini-3.5-flash", "gemini-flash-latest").distinct()) {
                            val r0 = postAi(m, key, body)
                            res = r0
                            used = m
                            if (r0.first != 404 && r0.first != 503 && r0.first != 500 && r0.first != 429) break
                        }
                        val c0 = res!!.first
                        if (c0 != 503 && c0 != 500 && c0 != 404 && c0 != 429) break
                        Thread.sleep(1200)
                    }
                    val r = res!!
                    if (r.first != 200) {
                        aiErr("Gemini", r.first, r.second)
                        emit(gen, seq, null)
                        return@execute
                    }
                    goodModel = used
                    val out = JSONObject(r.second).getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim()
                    emit(gen, seq, if (out.isEmpty() || out.contains("NONE", true)) null else out)
                }
            } catch (e: Exception) {
                js("nativeMsg(" + JSONObject.quote("تعذّر الاتصال — تأكد من الإنترنت") + ")")
                emit(gen, seq, null)
            }
        }
    }

    private fun startAi(engine: String, key: String, model: String) {
        val rate = 16000
        val frame = 480
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, rate, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, frame * 16))
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            fail("تعذّر تشغيل الميكروفون")
            return
        }
        goodModel = null
        aiOn = true
        val gen = ++aiGen
        synchronized(aiLock) {
            aiDone.clear()
            aiNext = 0
            aiSeq = 0
        }
        Thread {
            val buf = ShortArray(frame)
            val seg = java.io.ByteArrayOutputStream()
            val pre = java.util.ArrayDeque<ByteArray>()
            var speaking = false
            var voiced = 0
            var silent = 0
            var frames = 0
            var noise = 300.0
            try {
                rec.startRecording()
                while (aiOn && gen == aiGen) {
                    val n = rec.read(buf, 0, frame)
                    if (n <= 0) continue
                    var sum = 0.0
                    for (i in 0 until n) sum += buf[i].toDouble() * buf[i].toDouble()
                    val rms = Math.sqrt(sum / n)
                    val bytes = ByteArray(n * 2)
                    for (i in 0 until n) {
                        bytes[i * 2] = (buf[i].toInt() and 0xff).toByte()
                        bytes[i * 2 + 1] = (buf[i].toInt() shr 8).toByte()
                    }
                    val loud = rms > noise * 2.5 + 250
                    if (!speaking) {
                        noise = noise * 0.97 + rms * 0.03
                        pre.addLast(bytes)
                        if (pre.size > 10) pre.removeFirst()
                        voiced = if (loud) voiced + 1 else 0
                        if (voiced >= 3) {
                            speaking = true
                            seg.reset()
                            for (p in pre) seg.write(p)
                            pre.clear()
                            silent = 0
                            frames = 0
                        }
                    } else {
                        seg.write(bytes)
                        frames++
                        silent = if (loud) 0 else silent + 1
                        if (silent >= 23 || frames >= 300) {
                            speaking = false
                            voiced = 0
                            if (frames - silent >= 12) sendAi(seg.toByteArray(), engine, key, model)
                            seg.reset()
                        } else if (frames >= 170 && silent >= 3) {
                            sendAi(seg.toByteArray(), engine, key, model)
                            seg.reset()
                            frames = 0
                            silent = 0
                        }
                    }
                }
            } catch (e: Exception) {
            } finally {
                try { rec.stop() } catch (e: Exception) { }
                rec.release()
            }
        }.start()
    }

    inner class Bridge {
        @JavascriptInterface fun startAI(engine: String, key: String, model: String) {
            runOnUiThread {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    fail("اسمح للتطبيق بالميكروفون من إعدادات أندرويد")
                } else {
                    on = false
                    destroySr()
                    mute(false)
                    startAi(engine, key.trim(), model.trim().ifEmpty { "gemini-3.5-flash" })
                }
            }
        }
        @JavascriptInterface fun saveFile(name: String, b64: String) {
            pendingFile = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
            runOnUiThread {
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                i.putExtra(Intent.EXTRA_TITLE, name)
                startActivityForResult(i, 8)
            }
        }
        @JavascriptInterface fun start() {
            runOnUiThread {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    fail("اسمح للتطبيق بالميكروفون من إعدادات أندرويد")
                } else {
                    aiOn = false
                    aiGen++
                    on = true
                    mute(true)
                    listen()
                }
            }
        }
        @JavascriptInterface fun stop() {
            runOnUiThread { on = false; aiOn = false; aiGen++; destroySr(); mute(false) }
        }
        @JavascriptInterface fun setOpts(off: Boolean, seg: Boolean) {
            preferOffline = off
            segmented = seg
        }
        @JavascriptInterface fun speak(text: String) {
            runOnUiThread {
                if (ttsOk) {
                    val p = Bundle()
                    p.putInt(android.speech.tts.TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_ALARM)
                    tts?.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, p, "w")
                } else {
                    beep()
                }
            }
        }
        @JavascriptInterface fun beep() {
            try {
                val t = ToneGenerator(AudioManager.STREAM_ALARM, 100)
                t.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 500)
                h.postDelayed({ t.release() }, 800)
            } catch (e: Exception) { }
        }
    }

    override fun onDestroy() {
        try { tts?.shutdown() } catch (e: Exception) { }
        on = false
        aiOn = false
        aiGen++
        destroySr()
        mute(false)
        super.onDestroy()
    }
}
